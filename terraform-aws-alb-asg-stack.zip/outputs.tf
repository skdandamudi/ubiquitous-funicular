output "alb_dns_name" {
  description = "DNS name of the ALB (null when create_alb = false)."
  value       = one(aws_lb.this[*].dns_name)
}

output "alb_zone_id" {
  description = "Hosted zone ID of the ALB for Route53 alias records (null when create_alb = false)."
  value       = one(aws_lb.this[*].zone_id)
}

output "alb_arn" {
  description = "ARN of the ALB (null when create_alb = false)."
  value       = one(aws_lb.this[*].arn)
}

output "target_group_arn" {
  description = "ARN of the target group (null when create_alb = false)."
  value       = one(aws_lb_target_group.this[*].arn)
}

output "https_listener_arn" {
  description = "ARN of the HTTPS (443) listener (null when create_alb = false)."
  value       = one(aws_lb_listener.https[*].arn)
}

output "http_listener_arn" {
  description = "ARN of the HTTP (80) redirect listener (null when create_alb = false)."
  value       = one(aws_lb_listener.http[*].arn)
}

output "asg_name" {
  description = "Name of the Auto Scaling Group."
  value       = aws_autoscaling_group.this.name
}

output "autoscaling_policy_arn" {
  description = "ARN of the CPU target-tracking scaling policy."
  value       = aws_autoscaling_policy.cpu.arn
}

output "scheduled_action_arns" {
  description = "Map of scheduled action name to its ARN."
  value       = { for k, s in aws_autoscaling_schedule.this : k => s.arn }
}

output "launch_template_id" {
  description = "ID of the launch template."
  value       = aws_launch_template.this.id
}

output "vpc_id" {
  description = "ID of the discovered VPC."
  value       = data.aws_vpc.this.id
}

output "public_subnet_ids" {
  description = "Discovered public (ALB) subnet IDs."
  value       = data.aws_subnets.public.ids
}

output "private_subnet_ids" {
  description = "Discovered private (ASG) subnet IDs."
  value       = data.aws_subnets.private.ids
}

output "alb_security_group_id" {
  description = "ID of the ALB security group (null when create_alb = false)."
  value       = one(aws_security_group.alb[*].id)
}

output "instance_security_group_id" {
  description = "ID of the instance security group."
  value       = aws_security_group.instance.id
}

output "cloudwatch_alarm_arns" {
  description = "Map of enabled curated alarm name to its CloudWatch alarm ARN."
  value = {
    for k, v in {
      http_5xx             = try(aws_cloudwatch_metric_alarm.http_5xx[0].arn, null)
      unhealthy_hosts      = try(aws_cloudwatch_metric_alarm.unhealthy_hosts[0].arn, null)
      target_response_time = try(aws_cloudwatch_metric_alarm.target_response_time[0].arn, null)
      high_cpu             = try(aws_cloudwatch_metric_alarm.high_cpu[0].arn, null)
    } : k => v if v != null
  }
}
