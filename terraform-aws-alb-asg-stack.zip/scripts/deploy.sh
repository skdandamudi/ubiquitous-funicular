#!/usr/bin/env bash
set -euo pipefail

###############################################################################
# scripts/deploy.sh — Deploy the ALB/ASG stack with remote S3 state
#
# Runs terraform init/plan/apply/destroy/output against a Terraform root
# directory, wiring an S3 remote-state backend that is keyed by environment
# and application. State locking uses the S3 backend's native lockfile
# (Terraform >= 1.10) — no DynamoDB.
#
# Bucket naming convention:  terraform-state-<aws-account-id>-<region>
# Auto-detected from AWS credentials when -b is not provided, and created
# (versioned + encrypted + public-access-blocked) if it does not exist.
#
# State key:  <env>/<project>/<app>/terraform.tfstate
#
# Usage:
#   ./scripts/deploy.sh <command> -e <env> -p <project> -a <app> [options]
#
# Commands:
#   init        Initialise the backend (auto-detects/creates the S3 bucket)
#   plan        Run terraform plan
#   apply       Run terraform apply
#   destroy     Run terraform destroy
#   output      Run terraform output
#
# Options:
#   -e, --env <env>       Environment: dev, test, prod (required)
#   -p, --project <name>  Project name (required; groups apps in the state key)
#   -a, --app <name>      Application name (required)
#   -b, --bucket <name>   Override S3 state bucket (default: auto-detected)
#   -r, --region <region> AWS region (default: us-east-1)
#   -d, --dir <dir>       Terraform root directory (default: examples/complete)
#   -f, --var-file <file> Extra -var-file (auto-loads <dir>/<env>.tfvars if present)
#       --auto-approve    Skip interactive approval (apply / destroy)
#       --reconfigure     Reconfigure backend during init
#   -h, --help            Show this help
#
# Examples:
#   ./scripts/deploy.sh init  -e dev  -a web
#   ./scripts/deploy.sh plan  -e dev  -a web
#   ./scripts/deploy.sh apply -e prod -a web --auto-approve
#   ./scripts/deploy.sh destroy -e dev -a web --auto-approve
###############################################################################

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"

# ── Colours ──────────────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# ── Helpers ──────────────────────────────────────────────────────────────────
usage() {
  cat <<'HELP'
Usage:
  ./scripts/deploy.sh <command> -e <env> -p <project> -a <app> [options]

Commands:
  init        Initialise the backend (auto-detects/creates the S3 bucket)
  plan        Run terraform plan
  apply       Run terraform apply
  destroy     Run terraform destroy
  output      Run terraform output

Options:
  -e, --env <env>       Environment: dev, test, prod (required)
  -p, --project <name>  Project name (required; groups apps in the state key)
  -a, --app <name>      Application name (required)
  -b, --bucket <name>   Override S3 state bucket (default: auto-detected as
                        terraform-state-<account-id>-<region>)
  -r, --region <region> AWS region (default: us-east-1)
  -d, --dir <dir>       Terraform root directory (default: examples/complete)
  -f, --var-file <file> Explicit -var-file (otherwise auto-loads common.tfvars
                        + app *.tfvars, see Vars below)
      --auto-approve    Skip interactive approval (apply / destroy)
      --reconfigure     Reconfigure backend during init
  -h, --help            Show this help

State: s3://terraform-state-<account-id>-<region>/<env>/<project>/<app>/terraform.tfstate
Vars:  environments/<env>/<project>/common.tfvars, then
       environments/<env>/<project>/<app>/*.tfvars (app overrides common)
Locking: S3 native lockfile (Terraform >= 1.10) — no DynamoDB.

Examples:
  ./scripts/deploy.sh init  -e dev  -p devops -a web
  ./scripts/deploy.sh plan  -e dev  -p devops -a web
  ./scripts/deploy.sh apply -e prod -p devops -a web --auto-approve
HELP
  exit 0
}

die()     { echo -e "${RED}Error:${NC} $1" >&2; exit 1; }
info()    { echo -e "${CYAN}==>${NC} $1"; }
success() { echo -e "${GREEN}==>${NC} $1"; }
warn()    { echo -e "${YELLOW}==>${NC} $1"; }
banner()  { echo ""; echo -e "${BOLD}─── $1 ───${NC}"; }

# ── Bucket auto-detection ────────────────────────────────────────────────────
# Builds terraform-state-<account-id>-<region> from the active AWS credentials.
resolve_bucket() {
  local region="$1"
  local account_id

  command -v aws &>/dev/null || die "AWS CLI not found. Install it or pass -b / --bucket manually."

  account_id=$(aws sts get-caller-identity --query Account --output text 2>/dev/null) \
    || die "Failed to detect AWS account ID. Check your AWS credentials or pass -b / --bucket manually."

  echo "terraform-state-${account_id}-${region}"
}

# ── State bucket creation ────────────────────────────────────────────────────
# Creates the bucket if missing: versioned, encrypted, public access blocked.
ensure_state_bucket() {
  local bucket="$1" region="$2"

  if aws s3api head-bucket --bucket "$bucket" &>/dev/null; then
    return 0
  fi

  info "Creating state bucket ${bucket}"
  if [[ "$region" == "us-east-1" ]]; then
    aws s3api create-bucket --bucket "$bucket" --region "$region" >/dev/null
  else
    aws s3api create-bucket --bucket "$bucket" --region "$region" \
      --create-bucket-configuration "LocationConstraint=${region}" >/dev/null
  fi
  aws s3api put-bucket-versioning --bucket "$bucket" \
    --versioning-configuration Status=Enabled
  aws s3api put-bucket-encryption --bucket "$bucket" \
    --server-side-encryption-configuration \
    '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}'
  aws s3api put-public-access-block --bucket "$bucket" \
    --public-access-block-configuration \
    BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true
}

# ── Argument parsing ─────────────────────────────────────────────────────────
COMMAND=""
BUCKET=""
REGION="us-east-1"
ENV=""
PROJECT=""
APP=""
DIR="$ROOT_DIR/examples/complete"
VAR_FILE=""
AUTO_APPROVE=false
RECONFIGURE=false

[[ $# -eq 0 ]] && usage

# First positional argument is the command.
case "$1" in
  init|plan|apply|destroy|output) COMMAND="$1"; shift ;;
  -h|--help) usage ;;
  *) die "Unknown command: $1. Expected: init, plan, apply, destroy, output." ;;
esac

while [[ $# -gt 0 ]]; do
  case "$1" in
    -e|--env)      [[ $# -lt 2 ]] && die "--env requires a value";      ENV="$2";      shift 2 ;;
    -p|--project)  [[ $# -lt 2 ]] && die "--project requires a value";  PROJECT="$2";  shift 2 ;;
    -a|--app)      [[ $# -lt 2 ]] && die "--app requires a value";      APP="$2";      shift 2 ;;
    -b|--bucket)   [[ $# -lt 2 ]] && die "--bucket requires a value";   BUCKET="$2";   shift 2 ;;
    -r|--region)   [[ $# -lt 2 ]] && die "--region requires a value";   REGION="$2";   shift 2 ;;
    -d|--dir)      [[ $# -lt 2 ]] && die "--dir requires a value";      DIR="$2";      shift 2 ;;
    -f|--var-file) [[ $# -lt 2 ]] && die "--var-file requires a value"; VAR_FILE="$2"; shift 2 ;;
    --auto-approve) AUTO_APPROVE=true; shift ;;
    --reconfigure)  RECONFIGURE=true;  shift ;;
    -h|--help) usage ;;
    *) die "Unknown option: $1" ;;
  esac
done

# ── Validation ───────────────────────────────────────────────────────────────
command -v terraform &>/dev/null || die "terraform not found on PATH."
[[ -n "$ENV" ]]     || die "Environment required. Use -e/--env (e.g. dev, test, prod)."
[[ -n "$PROJECT" ]] || die "Project required. Use -p/--project."
[[ -n "$APP" ]]     || die "Application required. Use -a/--app."
[[ -d "$DIR" ]]     || die "Terraform directory not found: $DIR"

# Auto-detect the bucket when not overridden.
if [[ -z "$BUCKET" ]]; then
  BUCKET=$(resolve_bucket "$REGION")
  info "Auto-detected bucket: ${BUCKET}"
fi

STATE_KEY="${ENV}/${PROJECT}/${APP}/terraform.tfstate"

# Resolve var files. Explicit -f wins; otherwise load the project-level
# common.tfvars first, then every *.tfvars under the app directory (so app-level
# values override common). Absolute paths, so -chdir does not matter.
VARS_DIR="${ROOT_DIR}/environments/${ENV}/${PROJECT}/${APP}"
COMMON_TFVARS="${ROOT_DIR}/environments/${ENV}/${PROJECT}/common.tfvars"
var_file_args=()
if [[ -n "$VAR_FILE" ]]; then
  var_file_args+=(-var-file="$VAR_FILE")
else
  if [[ -f "$COMMON_TFVARS" ]]; then
    var_file_args+=(-var-file="$COMMON_TFVARS")
    info "Var file: environments/${ENV}/${PROJECT}/common.tfvars"
  fi
  shopt -s nullglob
  for f in "$VARS_DIR"/*.tfvars; do
    var_file_args+=(-var-file="$f")
    info "Var file: environments/${ENV}/${PROJECT}/${APP}/$(basename "$f")"
  done
  shopt -u nullglob
fi

# ── Backend init ─────────────────────────────────────────────────────────────
backend_init() {
  ensure_state_bucket "$BUCKET" "$REGION"
  info "State: s3://${BUCKET}/${STATE_KEY} (native lockfile)"
  local -a init_args=(init)
  $RECONFIGURE && init_args+=(-reconfigure)
  init_args+=(
    -backend-config="bucket=${BUCKET}"
    -backend-config="key=${STATE_KEY}"
    -backend-config="region=${REGION}"
  )
  terraform -chdir="$DIR" "${init_args[@]}"
}

# ── Run ──────────────────────────────────────────────────────────────────────
CMD_LABEL="$(printf '%s\n' "$COMMAND" | awk '{print toupper(substr($0,1,1)) substr($0,2)}')"
banner "${CMD_LABEL} — env=${ENV} project=${PROJECT} app=${APP} region=${REGION}"

# Assemble the module variable arguments shared by plan/apply/destroy.
tf_vars=(-var "environment=${ENV}" -var "app_name=${APP}")
[[ ${#var_file_args[@]} -gt 0 ]] && tf_vars+=("${var_file_args[@]}")

case "$COMMAND" in
  init)
    backend_init
    ;;
  plan)
    backend_init
    terraform -chdir="$DIR" plan "${tf_vars[@]}"
    ;;
  apply)
    backend_init
    apply_args=(apply "${tf_vars[@]}")
    $AUTO_APPROVE && apply_args+=(-auto-approve)
    terraform -chdir="$DIR" "${apply_args[@]}"
    ;;
  destroy)
    backend_init
    destroy_args=(destroy "${tf_vars[@]}")
    $AUTO_APPROVE && destroy_args+=(-auto-approve)
    terraform -chdir="$DIR" "${destroy_args[@]}"
    ;;
  output)
    terraform -chdir="$DIR" output
    ;;
esac

success "${CMD_LABEL} — done"
