resource "aws_launch_template" "this" {
  name_prefix   = "${local.name}-"
  image_id      = var.ami_id
  instance_type = var.instance_type
  key_name      = var.key_name
  user_data     = var.user_data == null ? null : base64encode(var.user_data)

  vpc_security_group_ids = [aws_security_group.instance.id]

  metadata_options {
    http_endpoint               = "enabled"
    http_tokens                 = "required" # enforce IMDSv2
    http_put_response_hop_limit = 1
  }

  block_device_mappings {
    device_name = var.root_device_name
    ebs {
      encrypted   = true
      volume_type = var.root_volume_type
      volume_size = var.root_volume_size
    }
  }

  dynamic "iam_instance_profile" {
    for_each = var.instance_profile_name == null ? [] : [var.instance_profile_name]
    content {
      name = iam_instance_profile.value
    }
  }

  tag_specifications {
    resource_type = "instance"
    tags          = merge(local.tags, { Name = "${local.name}-instance" })
  }

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_autoscaling_group" "this" {
  # name_prefix (not name) so create_before_destroy replacements never collide.
  name_prefix               = "${local.name}-"
  vpc_zone_identifier       = data.aws_subnets.private.ids
  min_size                  = var.min_size
  max_size                  = var.max_size
  desired_capacity          = var.desired_capacity
  target_group_arns         = var.create_alb ? [aws_lb_target_group.this[0].arn] : []
  health_check_type         = var.create_alb ? "ELB" : "EC2"
  health_check_grace_period = var.health_check_grace_period

  launch_template {
    id      = aws_launch_template.this.id
    version = "$Latest"
  }

  # Roll instances when the launch template changes: bring up new instances and
  # wait for them to pass the ELB health check before terminating old ones.
  dynamic "instance_refresh" {
    for_each = var.enable_instance_refresh ? [1] : []
    content {
      strategy = "Rolling"
      preferences {
        min_healthy_percentage = var.instance_refresh_min_healthy_percentage
        max_healthy_percentage = var.instance_refresh_max_healthy_percentage
        instance_warmup        = var.instance_refresh_warmup
      }
    }
  }

  dynamic "tag" {
    for_each = merge(local.tags, { Name = "${local.name}-instance" })
    content {
      key                 = tag.key
      value               = tag.value
      propagate_at_launch = true
    }
  }

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_autoscaling_policy" "cpu" {
  name                   = "${local.name}-cpu-target"
  autoscaling_group_name = aws_autoscaling_group.this.name
  policy_type            = "TargetTrackingScaling"

  target_tracking_configuration {
    predefined_metric_specification {
      predefined_metric_type = "ASGAverageCPUUtilization"
    }

    target_value = var.cpu_target_value
  }
}

# Opt-in scheduled scaling, applied on top of target tracking. Sizes left null
# are passed as -1 so that scheduled action does not change them.
resource "aws_autoscaling_schedule" "this" {
  for_each = var.scheduled_actions

  scheduled_action_name  = each.key
  autoscaling_group_name = aws_autoscaling_group.this.name

  recurrence = each.value.recurrence
  start_time = each.value.start_time
  end_time   = each.value.end_time
  time_zone  = each.value.time_zone

  min_size         = each.value.min_size != null ? each.value.min_size : -1
  max_size         = each.value.max_size != null ? each.value.max_size : -1
  desired_capacity = each.value.desired_capacity != null ? each.value.desired_capacity : -1
}
