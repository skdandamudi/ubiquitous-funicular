# terraform-aws-alb-asg-stack

Provisions a public or internal, HTTPS-terminated Application Load Balancer
fronting an EC2 Auto Scaling Group inside an existing, tag-discovered VPC.

## Features

- Discovers VPC and subnets via tags (no ID wiring).
- Optional public or internal ALB (`create_alb`): HTTPS (ACM) with HTTP→HTTPS 301 redirect.
  With `create_alb = false`, only the ASG/launch template/instance SG are created
  and the ASG uses EC2 health checks.
- Least-privilege security groups (ALB → instances on `app_port`).
- EC2 launch template with configurable AMI + user_data.
- CPU target-tracking autoscaling (AWS-managed alarms).
- Rolling instance refresh: new instances pass ELB health checks before old ones are terminated.
- Optional ALB access logging to a bring-your-own S3 bucket.
- Optional path/host-based HTTPS listener rules to caller-supplied target groups.
- Optional curated CloudWatch alarms (5xx, unhealthy hosts, latency, CPU).

## Required Network Tagging

The module looks up networking by tag. Your VPC and subnets must be tagged:

- VPC: `Name = <vpc_name>`
- Public subnets (ALB): `<subnet_tag_key> = <public_subnet_tag_value>` (default `Tier = public`)
- Private subnets (ASG): `<subnet_tag_key> = <private_subnet_tag_value>` (default `Tier = private`)

## Naming & Tagging

All resources are named `<environment>-<app_name>-<name>-<component>`
(e.g. `prod-web-demo-alb`). Keep the combined prefix short — AWS caps some
names (ALB, target group) at 32 characters.

Every resource is tagged with the merge of, in increasing precedence:
`default_tags` (baseline) → `tags` (additional) → the module's
`Environment` and `Application` tags (authoritative).

## Security defaults

Review these before production:

- **`ingress_cidr_blocks` defaults to `0.0.0.0/0`** on ports 80 and 443 — the
  ALB is world-open unless you restrict it.
- Instances enforce **IMDSv2** (`http_tokens = "required"`) and encrypt the
  **root EBS volume** by default.
- The ALB sets `drop_invalid_header_fields = true`; enable
  `enable_deletion_protection` in prod.
- Access logging is **off** until you set `access_logs_bucket`.

## Usage

```hcl
module "stack" {
  source = "github.com/your-org/terraform-aws-alb-asg-stack"

  environment     = "prod"
  app_name        = "web"
  name            = "demo"
  vpc_name        = "my-vpc"
  certificate_arn = "arn:aws:acm:us-east-1:123456789012:certificate/abc"
  ami_id          = "ami-0abc123"
}
```

See `examples/complete` for a full example.

## Deploying with remote state

`scripts/deploy.sh` provisions (if missing) and uses a remote S3 state backend
keyed by environment, project, and application. State locking uses the S3
backend's native lockfile (Terraform ≥ 1.10) — no DynamoDB.

- **State:** `s3://terraform-state-<account-id>-<region>/<env>/<project>/<app>/terraform.tfstate`
- **Var files:** `environments/<env>/<project>/common.tfvars` (project-level shared
  vars), then every `*.tfvars` under `environments/<env>/<project>/<app>/` (app
  values override common)

```bash
# command-first, like scripts/terraform.sh
scripts/deploy.sh init  -e dev  -p devops -a web
scripts/deploy.sh plan  -e dev  -p devops -a web
scripts/deploy.sh apply -e prod -p devops -a web --auto-approve
```

By default the state bucket name is derived from the caller's AWS account and
region (`terraform-state-<account-id>-<region>`) and created (versioned,
encrypted, public-access-blocked) if missing; override with `-b`. The script
passes `environment`/`app_name` as variables and auto-loads the project-level
`common.tfvars` followed by the app's `*.tfvars` (put shared values in common,
app-specific `vpc_name`/`certificate_arn`/`ami_id` in the app file), or pass an
explicit `-f`. Override the region or root directory with `-r`, `-d`.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| environment | Environment (e.g. dev/test/prod); prepended to names + Environment tag | string | — | yes |
| app_name | Application name; in names + Application tag | string | — | yes |
| name | Base name component | string | — | yes |
| vpc_name | VPC `Name` tag to look up | string | — | yes |
| vpc_tags | Extra tag filters for the VPC | map(string) | `{}` | no |
| subnet_tag_key | Tag key for subnet tiers | string | `"Tier"` | no |
| public_subnet_tag_value | Public (ALB) subnet tier value | string | `"public"` | no |
| private_subnet_tag_value | Private (ASG) subnet tier value | string | `"private"` | no |
| create_alb | Create the ALB + related resources; false = ASG only | bool | `true` | no |
| internal_alb | Internal ALB (private subnets) vs internet-facing (public subnets) | bool | `false` | no |
| certificate_arn | ACM cert ARN for HTTPS (required when `create_alb`) | string | `null` | no* |
| ssl_policy | SSL policy for the HTTPS listener | string | `"ELBSecurityPolicy-TLS13-1-2-2021-06"` | no |
| enable_deletion_protection | Enable ALB deletion protection | bool | `false` | no |
| ingress_cidr_blocks | Client CIDRs allowed to the ALB (⚠️ defaults to world-open) | list(string) | `["0.0.0.0/0"]` | no |
| ami_id | AMI ID for the launch template | string | — | yes |
| instance_type | EC2 instance type | string | `"t3.micro"` | no |
| user_data | Raw bootstrap script | string | `null` | no |
| app_port | App / target group port | number | `80` | no |
| deregistration_delay | Target group draining delay (seconds) | number | `300` | no |
| health_check_path | Target group health check path | string | `"/"` | no |
| root_device_name | Root block device name (AMI-dependent) | string | `"/dev/xvda"` | no |
| root_volume_size | Root EBS size (GiB); `null` = AMI default | number | `null` | no |
| root_volume_type | Root EBS volume type | string | `"gp3"` | no |
| min_size | ASG minimum | number | `1` | no |
| max_size | ASG maximum | number | `3` | no |
| desired_capacity | ASG desired | number | `2` | no |
| cpu_target_value | Target-tracking CPU % | number | `60` | no |
| health_check_grace_period | Seconds before ELB health checks count | number | `300` | no |
| enable_instance_refresh | Roll instances on launch-template change | bool | `true` | no |
| instance_refresh_min_healthy_percentage | Min % healthy during refresh (100 = new-before-old) | number | `100` | no |
| instance_refresh_max_healthy_percentage | Max % of desired during refresh (surge) | number | `200` | no |
| instance_refresh_warmup | New-instance warmup seconds (null = grace period) | number | `null` | no |
| scheduled_actions | Scheduled scaling actions (see below) | map(object) | `{}` | no |
| key_name | Optional EC2 key pair | string | `null` | no |
| instance_profile_name | Optional IAM instance profile | string | `null` | no |
| default_tags | Baseline tags applied to every resource | map(string) | `{}` | no |
| tags | Additional tags, layered over default_tags | map(string) | `{}` | no |
| access_logs_bucket | Existing S3 bucket for ALB access logs; `null` disables logging | string | `null` | no |
| access_logs_prefix | Optional key prefix for access logs | string | `null` | no |
| listener_rules | Extra HTTPS listener rules (see below) | list(object) | `[]` | no |
| alarms | Curated CloudWatch alarms (see below) | object | `{}` | no |

### `listener_rules`

Each element:

| Field | Type | Default | Notes |
|-------|------|---------|-------|
| priority | number | — | Unique rule priority (required). |
| target_group_arn | string | ASG target group | Where matched traffic forwards; defaults to this module's ASG target group. |
| path_patterns | list(string) | `[]` | Path match values. |
| host_headers | list(string) | `[]` | Host match values. |

At least one of `path_patterns` / `host_headers` is required per rule. The
HTTPS listener's default action (forward to the ASG target group) is
unchanged — rules only add routing on top of it.

### `scheduled_actions`

Opt-in time-based scaling applied **alongside** the CPU target-tracking policy.
The map is keyed by scheduled action name; each value:

| Field | Type | Notes |
|-------|------|-------|
| recurrence | string | Cron expression, e.g. `0 8 * * MON-FRI`. |
| start_time | string | One-off start (RFC3339, UTC). |
| end_time | string | Optional end time. |
| time_zone | string | IANA zone for `recurrence`, e.g. `America/New_York`. |
| min_size | number | Capacity at the scheduled time; omit to leave unchanged. |
| max_size | number | Omit to leave unchanged. |
| desired_capacity | number | Omit to leave unchanged. |

Each action must set `recurrence` and/or `start_time`. Omitted sizes are sent as
`-1` (no change).

```hcl
scheduled_actions = {
  scale-up-business-hours = { recurrence = "0 8 * * MON-FRI", time_zone = "America/New_York", min_size = 2, desired_capacity = 3 }
  scale-down-evening      = { recurrence = "0 20 * * MON-FRI", time_zone = "America/New_York", min_size = 1, desired_capacity = 1 }
}
```

### `alarms`

Curated CloudWatch alarms, each **off by default** and opt-in. Dimensions are
auto-wired to this stack's ALB / target group / ASG. Shared `alarm_actions` and
`ok_actions` (e.g. an existing SNS topic ARN) are applied to every enabled alarm.

| Field | Type | Default | Notes |
|-------|------|---------|-------|
| alarm_actions | list(string) | `[]` | Actions on ALARM (e.g. SNS ARNs). |
| ok_actions | list(string) | `[]` | Actions on OK. |
| http_5xx | object | disabled | `AWS/ApplicationELB HTTPCode_ELB_5XX_Count` (Sum). Default threshold 10. |
| unhealthy_hosts | object | disabled | `UnHealthyHostCount` (Max). Default threshold 1. |
| target_response_time | object | disabled | `TargetResponseTime` seconds (Avg). Default threshold 1. |
| high_cpu | object | disabled | `AWS/EC2 CPUUtilization` percent (Avg). Default threshold 80. |

Each alarm object accepts `enabled` (bool), `threshold` (number),
`period` (seconds), and `evaluation_periods` (number). All alarms compare with
`GreaterThanOrEqualToThreshold` and treat missing data as not breaching.

```hcl
alarms = {
  alarm_actions = ["arn:aws:sns:us-east-1:123456789012:alerts"]
  high_cpu        = { enabled = true, threshold = 85 }
  unhealthy_hosts = { enabled = true }
}
```

### ALB access logs

Logging is off unless you set `access_logs_bucket`. The module does **not**
create or manage the bucket — supply an existing bucket that already grants
the ELB log-delivery service write access. See the AWS docs for the exact
[bucket policy for ALB access logs](https://docs.aws.amazon.com/elasticloadbalancing/latest/application/enable-access-logging.html).

## Outputs

| Name | Description |
|------|-------------|
| alb_dns_name | DNS name of the ALB |
| alb_zone_id | Hosted zone ID of the ALB |
| alb_arn | ARN of the ALB |
| target_group_arn | ARN of the target group |
| asg_name | Name of the ASG |
| https_listener_arn | ARN of the HTTPS (443) listener |
| http_listener_arn | ARN of the HTTP (80) redirect listener |
| autoscaling_policy_arn | ARN of the CPU target-tracking policy |
| launch_template_id | ID of the launch template |
| vpc_id | ID of the discovered VPC |
| public_subnet_ids | Discovered public (ALB) subnet IDs |
| private_subnet_ids | Discovered private (ASG) subnet IDs |
| alb_security_group_id | ID of the ALB security group |
| instance_security_group_id | ID of the instance security group |
| cloudwatch_alarm_arns | Map of enabled alarm name → ARN |

## Requirements

- Terraform >= 1.5
- AWS provider ~> 5.0
