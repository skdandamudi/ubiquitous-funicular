variable "environment" {
  description = "Environment name (e.g. dev, test, prod). Prepended to resource names and added as the Environment tag."
  type        = string

  validation {
    condition     = length(trimspace(var.environment)) > 0
    error_message = "environment must be a non-empty string."
  }
}

variable "app_name" {
  description = "Application name. Included in resource names and added as the Application tag."
  type        = string

  validation {
    condition     = length(trimspace(var.app_name)) > 0
    error_message = "app_name must be a non-empty string."
  }
}

variable "name" {
  description = "Base name component, combined as <environment>-<app_name>-<name> for all resources."
  type        = string

  validation {
    condition     = length("${var.environment}-${var.app_name}-${var.name}") <= 24
    error_message = "environment-app_name-name combined must be <= 24 chars, to leave room for the -alb/-tg suffixes within AWS's 32-char name limit."
  }
}

variable "vpc_name" {
  description = "Value of the VPC 'Name' tag to look up."
  type        = string
}

variable "vpc_tags" {
  description = "Optional additional tag filters for the VPC lookup."
  type        = map(string)
  default     = {}
}

variable "subnet_tag_key" {
  description = "Tag key distinguishing subnet tiers."
  type        = string
  default     = "Tier"
}

variable "public_subnet_tag_value" {
  description = "Subnet tag value identifying public (ALB) subnets."
  type        = string
  default     = "public"
}

variable "private_subnet_tag_value" {
  description = "Subnet tag value identifying private (ASG) subnets."
  type        = string
  default     = "private"
}

variable "create_alb" {
  description = "Create the ALB and its related resources (target group, listeners, listener rules, ALB security group, ALB-based alarms). When false, only the ASG/launch-template/instance security group are created."
  type        = bool
  default     = true
}

variable "internal_alb" {
  description = "When true, provision an internal (non-internet-facing) ALB in the private subnets. When false, an internet-facing ALB in the public subnets."
  type        = bool
  default     = false
}

variable "certificate_arn" {
  description = "ACM certificate ARN for the HTTPS listener. Required when create_alb = true."
  type        = string
  default     = null
}

variable "ingress_cidr_blocks" {
  description = "CIDR blocks allowed to reach the ALB on 80/443. Defaults to 0.0.0.0/0 (world-open) — restrict before production."
  type        = list(string)
  default     = ["0.0.0.0/0"]

  validation {
    condition     = alltrue([for c in var.ingress_cidr_blocks : can(cidrhost(c, 0))])
    error_message = "ingress_cidr_blocks must all be valid CIDR notation (e.g. 10.0.0.0/8, 203.0.113.4/32)."
  }
}

variable "ami_id" {
  description = "AMI ID for the launch template."
  type        = string
}

variable "instance_type" {
  description = "EC2 instance type for the ASG."
  type        = string
  default     = "t3.micro"
}

variable "user_data" {
  description = "Raw bootstrap script; base64-encoded by the module."
  type        = string
  default     = null
}

variable "app_port" {
  description = "Port the application listens on / target group port."
  type        = number
  default     = 80

  validation {
    condition     = var.app_port > 0 && var.app_port <= 65535
    error_message = "app_port must be between 1 and 65535."
  }
}

variable "health_check_path" {
  description = "Target group health check path."
  type        = string
  default     = "/"
}

variable "min_size" {
  description = "ASG minimum size."
  type        = number
  default     = 1
}

variable "max_size" {
  description = "ASG maximum size."
  type        = number
  default     = 3

  validation {
    condition     = var.max_size >= var.min_size
    error_message = "max_size must be greater than or equal to min_size."
  }
}

variable "desired_capacity" {
  description = "ASG desired capacity."
  type        = number
  default     = 2

  validation {
    condition     = var.desired_capacity >= var.min_size && var.desired_capacity <= var.max_size
    error_message = "desired_capacity must be between min_size and max_size."
  }
}

variable "cpu_target_value" {
  description = "Target-tracking average CPU utilization percentage."
  type        = number
  default     = 60

  validation {
    condition     = var.cpu_target_value > 0 && var.cpu_target_value <= 100
    error_message = "cpu_target_value must be between 1 and 100."
  }
}

variable "health_check_grace_period" {
  description = "Seconds after instance launch before ELB health checks count (lets the app/container start)."
  type        = number
  default     = 300
}

variable "enable_instance_refresh" {
  description = "Roll instances via instance refresh when the launch template changes, bringing up healthy new instances before terminating old ones."
  type        = bool
  default     = true
}

variable "instance_refresh_min_healthy_percentage" {
  description = "Minimum percentage of the ASG that must stay healthy during a refresh. 100 forces new instances to be healthy before old ones are terminated."
  type        = number
  default     = 100

  validation {
    condition     = var.instance_refresh_min_healthy_percentage >= 0 && var.instance_refresh_min_healthy_percentage <= 100
    error_message = "instance_refresh_min_healthy_percentage must be between 0 and 100."
  }
}

variable "instance_refresh_max_healthy_percentage" {
  description = "Maximum percentage of desired capacity the ASG may run during a refresh. Must exceed 100 to allow surging new instances before terminating old ones (required when min_healthy_percentage = 100). Set null to omit."
  type        = number
  default     = 200
}

variable "instance_refresh_warmup" {
  description = "Seconds a new instance is given to warm up before counting toward healthy capacity during a refresh. Null uses health_check_grace_period."
  type        = number
  default     = null
}

variable "scheduled_actions" {
  description = "Opt-in scheduled scaling actions, keyed by action name, applied alongside the CPU target-tracking policy. Each sets capacities at a cron recurrence and/or a one-off start/end time. Omitted sizes are left unchanged (-1)."
  type = map(object({
    recurrence       = optional(string)
    start_time       = optional(string)
    end_time         = optional(string)
    time_zone        = optional(string)
    min_size         = optional(number)
    max_size         = optional(number)
    desired_capacity = optional(number)
  }))
  default = {}

  validation {
    condition = alltrue([
      for a in values(var.scheduled_actions) : a.recurrence != null || a.start_time != null
    ])
    error_message = "Each scheduled action must set recurrence (cron) and/or start_time."
  }
}

variable "key_name" {
  description = "Optional EC2 key pair name."
  type        = string
  default     = null
}

variable "instance_profile_name" {
  description = "Optional IAM instance profile name for instances."
  type        = string
  default     = null
}

variable "root_device_name" {
  description = "Root block device name for the launch template (varies by AMI: /dev/xvda for Amazon Linux, /dev/sda1 for Ubuntu)."
  type        = string
  default     = "/dev/xvda"
}

variable "root_volume_size" {
  description = "Root EBS volume size in GiB. When null, the AMI's default size is used."
  type        = number
  default     = null
}

variable "root_volume_type" {
  description = "Root EBS volume type."
  type        = string
  default     = "gp3"
}

variable "ssl_policy" {
  description = "SSL policy for the HTTPS listener."
  type        = string
  default     = "ELBSecurityPolicy-TLS13-1-2-2021-06"
}

variable "deregistration_delay" {
  description = "Target group deregistration (connection draining) delay in seconds."
  type        = number
  default     = 300

  validation {
    condition     = var.deregistration_delay >= 0 && var.deregistration_delay <= 3600
    error_message = "deregistration_delay must be between 0 and 3600 seconds."
  }
}

variable "enable_deletion_protection" {
  description = "Enable deletion protection on the ALB."
  type        = bool
  default     = false
}

variable "default_tags" {
  description = "Baseline tags applied to every resource in the stack (e.g. org-wide standards). Merged first; overridden by var.tags and by the module's Environment/Application tags."
  type        = map(string)
  default     = {}
}

variable "tags" {
  description = "Additional tags applied to all resources, layered on top of default_tags."
  type        = map(string)
  default     = {}
}

variable "access_logs_bucket" {
  description = "Existing S3 bucket name for ALB access logs. When null, access logging is disabled. The bucket must already allow ELB log delivery."
  type        = string
  default     = null
}

variable "access_logs_prefix" {
  description = "Optional key prefix for ALB access logs within the bucket."
  type        = string
  default     = null
}

variable "listener_rules" {
  description = "Additional HTTPS listener rules. Each rule needs a unique priority and at least one of path_patterns / host_headers. target_group_arn is optional and defaults to this module's ASG target group."
  type = list(object({
    priority         = number
    target_group_arn = optional(string)
    path_patterns    = optional(list(string), [])
    host_headers     = optional(list(string), [])
  }))
  default = []

  validation {
    condition = alltrue([
      for r in var.listener_rules : length(r.path_patterns) > 0 || length(r.host_headers) > 0
    ])
    error_message = "Each listener rule must set at least one of path_patterns or host_headers."
  }

  validation {
    condition     = length(distinct([for r in var.listener_rules : r.priority])) == length(var.listener_rules)
    error_message = "Each listener rule must have a unique priority."
  }
}

variable "alarms" {
  description = "Curated CloudWatch alarms for the ALB/ASG. Each alarm is opt-in via its enabled flag. alarm_actions/ok_actions (e.g. SNS topic ARNs) are applied to every enabled alarm."
  type = object({
    alarm_actions = optional(list(string), [])
    ok_actions    = optional(list(string), [])

    http_5xx = optional(object({
      enabled            = optional(bool, false)
      threshold          = optional(number, 10)
      period             = optional(number, 60)
      evaluation_periods = optional(number, 1)
    }), {})

    unhealthy_hosts = optional(object({
      enabled            = optional(bool, false)
      threshold          = optional(number, 1)
      period             = optional(number, 60)
      evaluation_periods = optional(number, 1)
    }), {})

    target_response_time = optional(object({
      enabled            = optional(bool, false)
      threshold          = optional(number, 1)
      period             = optional(number, 60)
      evaluation_periods = optional(number, 3)
    }), {})

    high_cpu = optional(object({
      enabled            = optional(bool, false)
      threshold          = optional(number, 80)
      period             = optional(number, 60)
      evaluation_periods = optional(number, 3)
    }), {})
  })
  default = {}
}
