terraform {
  # >= 1.10 for the S3 backend's native lockfile (use_lockfile), no DynamoDB.
  required_version = ">= 1.10"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }

  # Remote state in S3 with native locking. bucket/key/region are supplied at
  # init time by scripts/deploy.sh (-backend-config).
  backend "s3" {
    use_lockfile = true
    encrypt      = true
  }
}

provider "aws" {
  region = var.region
}

module "stack" {
  source = "../.."

  environment     = "dev"
  app_name        = "web"
  name            = "demo"
  vpc_name        = var.vpc_name
  certificate_arn = var.certificate_arn
  ami_id          = var.ami_id

  # FSCrawler's REST service listens on 8080 and answers 200 at /fscrawler.
  app_port          = 8080
  health_check_path = "/fscrawler"

  min_size         = 1
  max_size         = 3
  desired_capacity = 2
  cpu_target_value = 60

  # Scheduled scaling (alongside target tracking): scale up for business hours
  # on weekdays, scale back down in the evening. Times are in the given zone.
  scheduled_actions = {
    scale-up-business-hours = {
      recurrence       = "0 8 * * MON-FRI"
      time_zone        = "America/New_York"
      min_size         = 2
      desired_capacity = 3
    }
    scale-down-evening = {
      recurrence       = "0 20 * * MON-FRI"
      time_zone        = "America/New_York"
      min_size         = 1
      desired_capacity = 1
    }
  }

  # Bootstrap Docker and run FSCrawler's REST service from a template. The host
  # port matches app_port (8080) so the ALB target group can reach it.
  user_data = templatefile("${path.module}/templates/user_data.sh.tftpl", {
    container_image   = var.container_image
    host_port         = 8080
    container_port    = 8080
    job_name          = var.fscrawler_job_name
    elasticsearch_url = var.elasticsearch_url
  })

  # Optional ALB access logging (bring-your-own bucket).
  access_logs_bucket = var.access_logs_bucket
  access_logs_prefix = "demo-alb"

  # Listener rules. The first omits target_group_arn, so it routes to the
  # module's ASG target group by default. The second (optional) overrides the
  # target group to route /api/* to a separate service.
  listener_rules = concat(
    [
      {
        priority      = 200
        host_headers  = ["app.example.com"]
        path_patterns = []
      }
    ],
    var.api_target_group_arn == null ? [] : [
      {
        priority         = 100
        target_group_arn = var.api_target_group_arn
        path_patterns    = ["/api/*"]
        host_headers     = []
      }
    ]
  )

  # Curated CloudWatch alarms (opt-in). Enable high CPU here; wire an SNS
  # topic ARN via alarm_actions to be notified.
  alarms = {
    alarm_actions = var.alarm_sns_topic_arn == null ? [] : [var.alarm_sns_topic_arn]
    high_cpu = {
      enabled   = true
      threshold = 85
    }
  }

  tags = {
    Environment = "demo"
    ManagedBy   = "terraform"
  }
}
