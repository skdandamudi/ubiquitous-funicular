variable "region" {
  description = "AWS region."
  type        = string
  default     = "us-east-1"
}

variable "vpc_name" {
  description = "Name tag of the existing VPC."
  type        = string
}

variable "certificate_arn" {
  description = "ACM certificate ARN for HTTPS."
  type        = string
}

variable "ami_id" {
  description = "AMI ID for the instances."
  type        = string
}

variable "access_logs_bucket" {
  description = "Optional existing S3 bucket for ALB access logs."
  type        = string
  default     = null
}

variable "api_target_group_arn" {
  description = "Optional target group ARN to demonstrate a path-based listener rule (/api/*)."
  type        = string
  default     = null
}

variable "alarm_sns_topic_arn" {
  description = "Optional SNS topic ARN to receive CloudWatch alarm notifications."
  type        = string
  default     = null
}

variable "container_image" {
  description = "Container image the instances run and expose to the ALB."
  type        = string
  default     = "dadoonet/fscrawler:2.7"
}

variable "fscrawler_job_name" {
  description = "FSCrawler job name used for the REST service and settings directory."
  type        = string
  default     = "example"
}

variable "elasticsearch_url" {
  description = "Elasticsearch URL FSCrawler connects to (must be reachable from the instances)."
  type        = string
  default     = "http://127.0.0.1:9200"
}
