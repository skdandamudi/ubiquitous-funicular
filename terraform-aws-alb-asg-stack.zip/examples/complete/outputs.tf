output "alb_dns_name" {
  description = "DNS name of the ALB."
  value       = module.stack.alb_dns_name
}

output "asg_name" {
  description = "Name of the ASG."
  value       = module.stack.asg_name
}
