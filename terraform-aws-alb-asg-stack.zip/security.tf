resource "aws_security_group" "alb" {
  count = var.create_alb ? 1 : 0

  name        = "${local.name}-alb"
  description = "ALB ingress for ${local.name}"
  vpc_id      = data.aws_vpc.this.id
  tags        = merge(local.tags, { Name = "${local.name}-alb" })

  ingress {
    description = "HTTP"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = var.ingress_cidr_blocks
  }

  ingress {
    description = "HTTPS"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = var.ingress_cidr_blocks
  }

  egress {
    description = "All outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_security_group" "instance" {
  name        = "${local.name}-instance"
  description = "Instance ingress from ALB for ${local.name}"
  vpc_id      = data.aws_vpc.this.id
  tags        = merge(local.tags, { Name = "${local.name}-instance" })

  # App traffic from the ALB, only when the ALB is created.
  dynamic "ingress" {
    for_each = var.create_alb ? [1] : []
    content {
      description     = "App traffic from ALB"
      from_port       = var.app_port
      to_port         = var.app_port
      protocol        = "tcp"
      security_groups = [aws_security_group.alb[0].id]
    }
  }

  egress {
    description = "All outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
