resource "aws_cloudwatch_metric_alarm" "http_5xx" {
  count = var.create_alb && var.alarms.http_5xx.enabled ? 1 : 0

  alarm_name          = "${local.name}-alb-5xx"
  alarm_description   = "ALB 5XX responses for ${local.name}"
  namespace           = "AWS/ApplicationELB"
  metric_name         = "HTTPCode_ELB_5XX_Count"
  statistic           = "Sum"
  comparison_operator = "GreaterThanOrEqualToThreshold"
  threshold           = var.alarms.http_5xx.threshold
  period              = var.alarms.http_5xx.period
  evaluation_periods  = var.alarms.http_5xx.evaluation_periods
  treat_missing_data  = "notBreaching"

  dimensions = {
    LoadBalancer = aws_lb.this[0].arn_suffix
  }

  alarm_actions = var.alarms.alarm_actions
  ok_actions    = var.alarms.ok_actions
  tags          = merge(local.tags, { Name = "${local.name}-alb-5xx" })
}

resource "aws_cloudwatch_metric_alarm" "unhealthy_hosts" {
  count = var.create_alb && var.alarms.unhealthy_hosts.enabled ? 1 : 0

  alarm_name          = "${local.name}-unhealthy-hosts"
  alarm_description   = "Unhealthy target count for ${local.name}"
  namespace           = "AWS/ApplicationELB"
  metric_name         = "UnHealthyHostCount"
  statistic           = "Maximum"
  comparison_operator = "GreaterThanOrEqualToThreshold"
  threshold           = var.alarms.unhealthy_hosts.threshold
  period              = var.alarms.unhealthy_hosts.period
  evaluation_periods  = var.alarms.unhealthy_hosts.evaluation_periods
  treat_missing_data  = "notBreaching"

  dimensions = {
    TargetGroup  = aws_lb_target_group.this[0].arn_suffix
    LoadBalancer = aws_lb.this[0].arn_suffix
  }

  alarm_actions = var.alarms.alarm_actions
  ok_actions    = var.alarms.ok_actions
  tags          = merge(local.tags, { Name = "${local.name}-unhealthy-hosts" })
}

resource "aws_cloudwatch_metric_alarm" "target_response_time" {
  count = var.create_alb && var.alarms.target_response_time.enabled ? 1 : 0

  alarm_name          = "${local.name}-response-time"
  alarm_description   = "Target response time for ${local.name}"
  namespace           = "AWS/ApplicationELB"
  metric_name         = "TargetResponseTime"
  statistic           = "Average"
  unit                = "Seconds"
  comparison_operator = "GreaterThanOrEqualToThreshold"
  threshold           = var.alarms.target_response_time.threshold
  period              = var.alarms.target_response_time.period
  evaluation_periods  = var.alarms.target_response_time.evaluation_periods
  treat_missing_data  = "notBreaching"

  dimensions = {
    LoadBalancer = aws_lb.this[0].arn_suffix
  }

  alarm_actions = var.alarms.alarm_actions
  ok_actions    = var.alarms.ok_actions
  tags          = merge(local.tags, { Name = "${local.name}-response-time" })
}

resource "aws_cloudwatch_metric_alarm" "high_cpu" {
  count = var.alarms.high_cpu.enabled ? 1 : 0

  alarm_name          = "${local.name}-high-cpu"
  alarm_description   = "High CPU utilization for ${local.name}"
  namespace           = "AWS/EC2"
  metric_name         = "CPUUtilization"
  statistic           = "Average"
  unit                = "Percent"
  comparison_operator = "GreaterThanOrEqualToThreshold"
  threshold           = var.alarms.high_cpu.threshold
  period              = var.alarms.high_cpu.period
  evaluation_periods  = var.alarms.high_cpu.evaluation_periods
  treat_missing_data  = "notBreaching"

  dimensions = {
    AutoScalingGroupName = aws_autoscaling_group.this.name
  }

  alarm_actions = var.alarms.alarm_actions
  ok_actions    = var.alarms.ok_actions
  tags          = merge(local.tags, { Name = "${local.name}-high-cpu" })
}
