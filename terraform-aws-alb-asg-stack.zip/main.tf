locals {
  name = "${var.environment}-${var.app_name}-${var.name}"

  # default_tags is the baseline, var.tags layers on top, and the module's
  # Environment/Application tags are authoritative (applied last).
  tags = merge(var.default_tags, var.tags, {
    Environment = var.environment
    Application = var.app_name
  })

  # An internal ALB lives in the private subnets; a public one in the public subnets.
  alb_subnet_ids = var.internal_alb ? data.aws_subnets.private.ids : data.aws_subnets.public.ids
}

data "aws_vpc" "this" {
  tags = merge({ Name = var.vpc_name }, var.vpc_tags)
}

data "aws_subnets" "public" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.this.id]
  }

  tags = {
    (var.subnet_tag_key) = var.public_subnet_tag_value
  }
}

data "aws_subnets" "private" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.this.id]
  }

  tags = {
    (var.subnet_tag_key) = var.private_subnet_tag_value
  }
}

# Fail at plan time with a clear message if the subnet tag filters match nothing,
# instead of surfacing an opaque AWS API error at apply.
# Public subnets are only required for a public (internet-facing) ALB.
check "public_subnets_exist" {
  assert {
    condition     = !var.create_alb || var.internal_alb || length(data.aws_subnets.public.ids) > 0
    error_message = "No public subnets found in VPC ${data.aws_vpc.this.id} matching ${var.subnet_tag_key}=${var.public_subnet_tag_value} (required for a public ALB; set internal_alb = true for an internal one)."
  }
}

check "private_subnets_exist" {
  assert {
    condition     = length(data.aws_subnets.private.ids) > 0
    error_message = "No private subnets found in VPC ${data.aws_vpc.this.id} matching ${var.subnet_tag_key}=${var.private_subnet_tag_value}."
  }
}
