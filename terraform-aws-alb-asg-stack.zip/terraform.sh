#!/usr/bin/env bash
set -euo pipefail

###############################################################################
# scripts/terraform.sh — Comprehensive Terraform layer runner
#
# Replaces init-all.sh, plan-all.sh, and apply-all.sh with a single entry
# point that dynamically injects the S3 backend bucket name at init time.
#
# Bucket naming convention:  terraform-state-<aws-account-id>-<region>
# Auto-detected from AWS credentials when -b is not provided.
#
# Each environment (dev, staging, prod) uses a separate AWS account.
# State isolation comes from different S3 buckets per account.
#
# Usage:
#   ./scripts/terraform.sh <command> [options] [layer...]
#
# Commands:
#   init        Initialise layers (auto-detects S3 bucket from AWS credentials)
#   plan        Run terraform plan
#   apply       Run terraform apply
#   destroy     Run terraform destroy (reverse layer order)
#   output      Run terraform output
#
# Options:
#   -e, --env <env>         Target environment: dev, staging, prod (required
#                           for all infra layers; ignored for bootstrap)
#   -p, --project <name>    Project name (e.g. sharedservices). Inserted into
#                           the cluster name ({env}-{project}-eks) and the
#                           state key (devops/{env}/{project}/{layer}/…).
#                           Omit for the default {env}-eks naming.
#   -b, --bucket <name>     Override S3 bucket name (default: auto-detected)
#   -r, --region <region>   AWS region (default: us-east-1)
#       --auto-approve      Skip interactive approval (apply / destroy)
#       --reconfigure       Reconfigure backend during init
#       --migrate-state     Migrate state during init
#   -h, --help              Show this help
#
# Layers (use short or full names):
#   tf-state-setup →  00-tf-state-setup  (local backend, one-time setup)
#   bootstrap      →  01-bootstrap       (ECR repos)
#   eks            →  02-eks
#   platform       →  03-platform
#   argocd         →  04-argocd
#   nexus          →  05-nexus
#   jenkins        →  06-jenkins
#   coder          →  07-coder
#   harbor         →  08-harbor
#   velero         →  09-velero
#   sonarqube      →  10-sonarqube
#   aws-reports    →  11-aws-reports
#
#   Omit the layer argument to target all infra layers (02-eks → 11-aws-reports).
#   Bootstrap must be targeted explicitly.
#
# Examples:
#   # One-time state setup (local backend — no bucket needed)
#   ./scripts/terraform.sh init    tf-state-setup
#   ./scripts/terraform.sh apply   tf-state-setup --auto-approve
#
#   # Bootstrap (ECR repos — uses S3 backend)
#   ./scripts/terraform.sh init    bootstrap
#   ./scripts/terraform.sh apply   bootstrap --auto-approve
#
#   # Initialise all infra layers for dev
#   ./scripts/terraform.sh init -e dev
#
#   # Plan / apply everything for prod
#   ./scripts/terraform.sh plan -e prod
#   ./scripts/terraform.sh apply -e prod --auto-approve
#
#   # Plan / apply a named project (state: devops/prod/sharedservices/eks/…)
#   ./scripts/terraform.sh plan -e prod -p sharedservices
#   ./scripts/terraform.sh apply -e prod -p sharedservices --auto-approve
#
#   # Target a single layer
#   ./scripts/terraform.sh plan -e staging platform
#   ./scripts/terraform.sh destroy -e dev argocd --auto-approve
###############################################################################

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"
LAYERS_DIR="$ROOT_DIR/layers"

# ── Colours ──────────────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# ── Layer definitions ────────────────────────────────────────────────────────
# Order matters — deploy order for apply, reversed for destroy.
INFRA_LAYERS=(
  "02-eks"
  "03-platform"
  "04-argocd"
  "05-nexus"
  "06-jenkins"
  "07-coder"
  "08-harbor"
  "09-velero"
  "10-sonarqube"
  "11-aws-reports"
)

VALID_ENVS=("dev" "staging" "prod")

resolve_layer() {
  case "$1" in
    tf-state-setup) echo "00-tf-state-setup" ;;
    bootstrap)      echo "01-bootstrap" ;;
    eks)            echo "02-eks" ;;
    platform)       echo "03-platform" ;;
    argocd)         echo "04-argocd" ;;
    nexus)          echo "05-nexus" ;;
    jenkins)        echo "06-jenkins" ;;
    coder)          echo "07-coder" ;;
    harbor)         echo "08-harbor" ;;
    velero)         echo "09-velero" ;;
    sonarqube)      echo "10-sonarqube" ;;
    aws-reports)    echo "11-aws-reports" ;;
    [0-9][0-9]-*)   echo "$1" ;;
    *)  return 1 ;;
  esac
}

# ── Helpers ──────────────────────────────────────────────────────────────────
usage() {
  cat <<'HELP'
Usage:
  ./scripts/terraform.sh <command> [options] [layer...]

Commands:
  init        Initialise layers (auto-detects S3 bucket from AWS credentials)
  plan        Run terraform plan
  apply       Run terraform apply
  destroy     Run terraform destroy (reverse layer order)
  output      Run terraform output

Options:
  -e, --env <env>         Target environment: dev, staging, prod (required
                          for all infra layers; ignored for bootstrap)
  -p, --project <name>    Project name (e.g. sharedservices). Inserted into
                          the cluster name ({env}-{project}-eks) and the
                          state key (devops/{env}/{project}/{layer}/...).
                          Omit for the default {env}-eks naming.
  -b, --bucket <name>     Override S3 bucket name (default: auto-detected as
                          terraform-state-<account-id>-<region>)
  -r, --region <region>   AWS region (default: us-east-1)
      --auto-approve      Skip interactive approval (apply / destroy)
      --reconfigure       Reconfigure backend during init
      --migrate-state     Migrate state during init
  -h, --help              Show this help

Layers (use short or full names):
  tf-state-setup ->  00-tf-state-setup  (local backend, one-time setup)
  bootstrap      ->  01-bootstrap       (ECR repos)
  eks            ->  02-eks
  platform       ->  03-platform
  argocd         ->  04-argocd
  nexus          ->  05-nexus
  jenkins        ->  06-jenkins
  coder          ->  07-coder
  harbor         ->  08-harbor
  velero         ->  09-velero
  sonarqube      ->  10-sonarqube
  aws-reports    ->  11-aws-reports

  Omit the layer argument to target all infra layers (02-eks -> 11-aws-reports).
  tf-state-setup and bootstrap must be targeted explicitly.

Examples:
  # One-time state setup (local backend -- no bucket needed)
  ./scripts/terraform.sh init    tf-state-setup
  ./scripts/terraform.sh apply   tf-state-setup --auto-approve

  # Bootstrap (ECR repos -- uses S3 backend)
  ./scripts/terraform.sh init    bootstrap
  ./scripts/terraform.sh apply   bootstrap --auto-approve

  # Initialise all infra layers for dev
  ./scripts/terraform.sh init -e dev

  # Plan / apply everything for prod
  ./scripts/terraform.sh plan -e prod
  ./scripts/terraform.sh apply -e prod --auto-approve

  # Plan / apply a named project (cluster: prod-sharedservices-eks)
  ./scripts/terraform.sh plan -e prod -p sharedservices
  ./scripts/terraform.sh apply -e prod -p sharedservices --auto-approve

  # Target a single layer
  ./scripts/terraform.sh plan -e staging platform
  ./scripts/terraform.sh destroy -e dev argocd --auto-approve
HELP
  exit 0
}

die() {
  echo -e "${RED}Error:${NC} $1" >&2
  exit 1
}

info() {
  echo -e "${CYAN}==>${NC} $1"
}

success() {
  echo -e "${GREEN}==>${NC} $1"
}

warn() {
  echo -e "${YELLOW}==>${NC} $1"
}

banner() {
  echo ""
  echo -e "${BOLD}─── $1 ───${NC}"
}

# ── Bucket auto-detection ────────────────────────────────────────────────────
# Builds terraform-state-<account-id>-<region> from the active AWS credentials.
resolve_bucket() {
  local region="$1"
  local account_id

  command -v aws &>/dev/null || die "AWS CLI not found. Install it or pass -b / --bucket manually."

  account_id=$(aws sts get-caller-identity --query Account --output text 2>/dev/null) \
    || die "Failed to detect AWS account ID. Check your AWS credentials or pass -b / --bucket manually."

  echo "terraform-state-${account_id}-${region}"
}

# ── DynamoDB table auto-detection ────────────────────────────────────────────
# Builds terraform-lock-<account-id>-<region> from the active AWS credentials.
resolve_dynamodb_table() {
  local region="$1"
  local account_id

  command -v aws &>/dev/null || die "AWS CLI not found."

  account_id=$(aws sts get-caller-identity --query Account --output text 2>/dev/null) \
    || die "Failed to detect AWS account ID."

  echo "terraform-lock-${account_id}-${region}"
}

# ── Tfvars resolution ────────────────────────────────────────────────────────
# Maps a layer name to its environment-specific tfvars file.
# Strips numeric prefix: 02-eks → eks.tfvars, 03-platform → platform.tfvars
#
# When a project is specified (-p flag), looks for project-specific tfvars
# first at environments/<env>/<project>/<layer>.tfvars. Falls back to the
# shared environment file at environments/<env>/<layer>.tfvars.
#
# Returns the resolved path and sets TFVARS_IS_PROJECT_SPECIFIC=true/false
# so callers know whether to inject -var project_name.
TFVARS_IS_PROJECT_SPECIFIC=false

resolve_tfvars() {
  local layer="$1"
  local env="$2"
  local project="$3"
  local short_name="${layer#[0-9][0-9]-}"

  TFVARS_IS_PROJECT_SPECIFIC=false

  # Try project-specific tfvars first.
  if [[ -n "$project" ]]; then
    local project_tfvars="$ROOT_DIR/environments/$env/$project/$short_name.tfvars"
    if [[ -f "$project_tfvars" ]]; then
      TFVARS_IS_PROJECT_SPECIFIC=true
      info "Using project tfvars: environments/${env}/${project}/${short_name}.tfvars" >&2
      echo "$project_tfvars"
      return
    else
      warn "No project tfvars at environments/${env}/${project}/${short_name}.tfvars — falling back to shared" >&2
    fi
  fi

  # Fall back to shared environment tfvars.
  local tfvars_path="$ROOT_DIR/environments/$env/$short_name.tfvars"
  [[ -f "$tfvars_path" ]] || die "Tfvars file not found: $tfvars_path"

  echo "$tfvars_path"
}

# ── Argument parsing ─────────────────────────────────────────────────────────
COMMAND=""
BUCKET=""
REGION="us-east-1"
ENV=""
PROJECT=""
AUTO_APPROVE=false
RECONFIGURE=false
MIGRATE_STATE=false
TARGET_LAYERS=()

[[ $# -eq 0 ]] && usage

# First positional argument is the command.
case "$1" in
  init|plan|apply|destroy|output) COMMAND="$1"; shift ;;
  -h|--help) usage ;;
  *) die "Unknown command: $1. Expected: init, plan, apply, destroy, output." ;;
esac

# Remaining arguments: options and optional layer names.
while [[ $# -gt 0 ]]; do
  case "$1" in
    -e|--env)
      [[ $# -lt 2 ]] && die "--env requires a value"
      ENV="$2"; shift 2 ;;
    -p|--project)
      [[ $# -lt 2 ]] && die "--project requires a value"
      PROJECT="$2"; shift 2 ;;
    -b|--bucket)
      [[ $# -lt 2 ]] && die "--bucket requires a value"
      BUCKET="$2"; shift 2 ;;
    -r|--region)
      [[ $# -lt 2 ]] && die "--region requires a value"
      REGION="$2"; shift 2 ;;
    --auto-approve)  AUTO_APPROVE=true;  shift ;;
    --reconfigure)   RECONFIGURE=true;   shift ;;
    --migrate-state) MIGRATE_STATE=true; shift ;;
    -h|--help) usage ;;
    -*)  die "Unknown option: $1" ;;
    *)
      resolved=$(resolve_layer "$1") || die "Unknown layer: $1"
      TARGET_LAYERS+=("$resolved")
      shift ;;
  esac
done

# Default: all infra layers when none specified.
if [[ ${#TARGET_LAYERS[@]} -eq 0 ]]; then
  TARGET_LAYERS=("${INFRA_LAYERS[@]}")
fi

# ── Validate environment ─────────────────────────────────────────────────────
# -e is required for any non-bootstrap infra layer.
needs_env=false
for layer in "${TARGET_LAYERS[@]}"; do
  if [[ "$layer" != "00-tf-state-setup" && "$layer" != "01-bootstrap" ]]; then
    needs_env=true
    break
  fi
done

if $needs_env; then
  [[ -n "$ENV" ]] || die "Environment required. Use -e/--env with one of: ${VALID_ENVS[*]}"

  valid=false
  for v in "${VALID_ENVS[@]}"; do
    [[ "$ENV" == "$v" ]] && valid=true && break
  done
  $valid || die "Invalid environment '$ENV'. Must be one of: ${VALID_ENVS[*]}"
fi

# Reverse layer order for destroy.
if [[ "$COMMAND" == "destroy" ]]; then
  reversed=()
  for (( i=${#TARGET_LAYERS[@]}-1; i>=0; i-- )); do
    reversed+=("${TARGET_LAYERS[$i]}")
  done
  TARGET_LAYERS=("${reversed[@]}")
fi

# ── Run a command against one layer ──────────────────────────────────────────
run_layer() {
  local layer="$1"
  local layer_dir="$LAYERS_DIR/$layer"

  [[ -d "$layer_dir" ]] || die "Layer directory not found: $layer_dir"

  local -a tf_args=()

  case "$COMMAND" in
    # ── init ──────────────────────────────────────────────────────────────
    init)
      tf_args=(init)

      if [[ "$layer" == "00-tf-state-setup" ]]; then
        info "tf-state-setup uses a local backend — no bucket required"
      else
        # Auto-detect bucket name from AWS credentials when not explicitly set.
        if [[ -z "$BUCKET" ]]; then
          BUCKET=$(resolve_bucket "$REGION")
          info "Auto-detected bucket: ${BUCKET}"
        fi
        local dynamodb_table
        dynamodb_table=$(resolve_dynamodb_table "$REGION")
        info "DynamoDB lock table: ${dynamodb_table}"
        tf_args+=(-backend-config="bucket=${BUCKET}")
        tf_args+=(-backend-config="region=${REGION}")
        tf_args+=(-backend-config="dynamodb_table=${dynamodb_table}")

        # Inject environment-scoped state key for infra layers.
        # Bootstrap keeps a static key (devops/bootstrap/terraform.tfstate)
        # since it has no environment dimension.
        # When a project is specified the key becomes
        # devops/{env}/{project}/{layer}/terraform.tfstate to isolate
        # each project's state within the same account.
        if [[ "$layer" != "01-bootstrap" && -n "$ENV" ]]; then
          local short_name="${layer#[0-9][0-9]-}"
          local state_key
          if [[ -n "$PROJECT" ]]; then
            state_key="devops/${ENV}/${PROJECT}/${short_name}/terraform.tfstate"
          else
            state_key="devops/${ENV}/${short_name}/terraform.tfstate"
          fi
          tf_args+=(-backend-config="key=${state_key}")
          info "State key: ${state_key}"
        fi
      fi

      $RECONFIGURE   && tf_args+=(-reconfigure)
      $MIGRATE_STATE && tf_args+=(-migrate-state)
      ;;

    # ── plan ──────────────────────────────────────────────────────────────
    plan)
      if [[ "$layer" == "00-tf-state-setup" || "$layer" == "01-bootstrap" ]]; then
        tf_args=(plan -var-file=terraform.tfvars)
      else
        local tfvars
        tfvars=$(resolve_tfvars "$layer" "$ENV" "$PROJECT")
        tf_args=(plan -var-file="$tfvars")
        # Only inject -var override when using the shared (non-project) tfvars,
        # since project-specific tfvars already contain the correct project_name.
        if [[ -n "$PROJECT" && "$TFVARS_IS_PROJECT_SPECIFIC" == "false" ]]; then
          tf_args+=(-var "project_name=${PROJECT}")
        fi
      fi
      ;;

    # ── apply ─────────────────────────────────────────────────────────────
    apply)
      if [[ "$layer" == "00-tf-state-setup" || "$layer" == "01-bootstrap" ]]; then
        tf_args=(apply -var-file=terraform.tfvars)
      else
        local tfvars
        tfvars=$(resolve_tfvars "$layer" "$ENV" "$PROJECT")
        tf_args=(apply -var-file="$tfvars")
        if [[ -n "$PROJECT" && "$TFVARS_IS_PROJECT_SPECIFIC" == "false" ]]; then
          tf_args+=(-var "project_name=${PROJECT}")
        fi
      fi
      $AUTO_APPROVE && tf_args+=(-auto-approve)
      ;;

    # ── destroy ───────────────────────────────────────────────────────────
    destroy)
      if [[ "$layer" == "00-tf-state-setup" || "$layer" == "01-bootstrap" ]]; then
        tf_args=(destroy -var-file=terraform.tfvars)
      else
        local tfvars
        tfvars=$(resolve_tfvars "$layer" "$ENV" "$PROJECT")
        tf_args=(destroy -var-file="$tfvars")
        if [[ -n "$PROJECT" && "$TFVARS_IS_PROJECT_SPECIFIC" == "false" ]]; then
          tf_args+=(-var "project_name=${PROJECT}")
        fi
      fi
      $AUTO_APPROVE && tf_args+=(-auto-approve)
      ;;

    # ── output ────────────────────────────────────────────────────────────
    output)
      tf_args=(output)
      ;;
  esac

  terraform -chdir="$layer_dir" "${tf_args[@]}"
}

# ── Main loop ────────────────────────────────────────────────────────────────
# Capitalise command label (bash 3.2 compatible — no ${var^}).
CMD_LABEL="$(printf '%s\n' "$COMMAND" | awk '{print toupper(substr($0,1,1)) substr($0,2)}')"

layer_count=${#TARGET_LAYERS[@]}
current=0
failed=0

if [[ -n "$ENV" && -n "$PROJECT" ]]; then
  info "${CMD_LABEL} — env=${ENV} project=${PROJECT} — ${layer_count} layer(s): ${TARGET_LAYERS[*]}"
elif [[ -n "$ENV" ]]; then
  info "${CMD_LABEL} — env=${ENV} — ${layer_count} layer(s): ${TARGET_LAYERS[*]}"
else
  info "${CMD_LABEL} — ${layer_count} layer(s): ${TARGET_LAYERS[*]}"
fi

for layer in "${TARGET_LAYERS[@]}"; do
  current=$((current + 1))
  banner "${CMD_LABEL} [${current}/${layer_count}]  ${layer}"

  if run_layer "$layer"; then
    success "${layer} — done"
  else
    failed=$((failed + 1))
    warn "${layer} — FAILED (exit code $?)"
    if [[ "$COMMAND" == "apply" || "$COMMAND" == "destroy" ]]; then
      die "Stopping — ${layer} failed. Fix the issue and re-run."
    fi
  fi
done

echo ""
if [[ $failed -eq 0 ]]; then
  success "All ${layer_count} layer(s) completed successfully."
else
  die "${failed} layer(s) failed."
fi
